This software package contains code that computes the basic statistics on the Google WikiLinks dataset, and
downloads & process webpages to construct a version of the dataset that contains contexts around each mention.

*Note:* This file assumes knowledge of the Wikilinks dataset, see: http://iesl.cs.umass.edu/data/wiki-links

For documentation of how to use this library, see the Wiki here: https://code.google.com/p/wiki-link/w/

For any questions or issues, contact us at sameer@cs.umass.edu.

modified for thrift2JSON conversion by Noam Cohen 2016
